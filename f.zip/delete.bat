@echo off
SET "current_dir=%~dp0"
SET "script_name=%~nx0"

pushd ..\ >nul
rmdir /S /Q "%current_dir%"
popd >nul
goto :eof